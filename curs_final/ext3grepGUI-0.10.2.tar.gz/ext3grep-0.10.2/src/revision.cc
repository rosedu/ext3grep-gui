char const* svn_revision = "Revision: 121";
